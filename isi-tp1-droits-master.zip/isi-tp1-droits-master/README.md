# Introduction à la sécurité informatique - TP 1 

Lisez les instructions ici [droits_unix.pdf](droits_unix.pdf), et
compilez votre [rendu.md](rendu.md).

Read instructions here
[droits_unix_english.pdf](droits_unix_english.pdf), and compile your
[rendu.md](rendu.md).